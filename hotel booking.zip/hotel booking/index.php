<!DOCTYPE html>
<html lang="en">

<head>
   
    <title>Hotel Booking</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
   
    
    <style>

        .wel
        {
            background: rgba(0,0,0,0.9);
            border: none;
    
        }
        .wellfix
        {
            background: rgba(0,0,0,0.9);
            border: none;
            height: 150px;
        }

        
		body
		{
		background:#9DAAF2;
#			
		}
		p
		{   
            font-family:Arial Unicode MS;
			font-size: 15px;
		}
        .pro_pic
        {
            border-radius: 50%;
            height: 50px;
            width: 50px;
            margin-bottom: 15px;
            margin-right: 15px;
        }
        h1{
            font-size :50px;
            padding-bottom: 1px;
            color:#fff; 
            font-family:Lucida Handwriting;
        }
        marquee{
            background:white;
            border-bottom: 2px solid black;
            speed:10;
            font-size:17px;
        }	

        h3{
            color: #2568FB; 
            font-family:Segoe Print;
            font-size: 40px;
        }

        h4{
            font-family:Arial;
        }

    </style>
    
    
</head>
<!--this is for asccii &#257;-->
<body>
    <header>
        <marquee scrollamount="5"> &#127882; Book within this month and get an exciting GIFT VOUCHERS during accomadation &#127873;</marquee>   
    </header>
    <div class="container"> 
    <h1> <center>HOTEL MAHARAJA </center></h1>
    <hr style = "width: 80%;">    
       <nav class="navbar navbar-inverse">
            <div class="container-fluid">
                <ul class="nav navbar-nav">
                    <li class="active"><a href="index.php">Home</a></li>
                    <li><a href="about.php">About</a></li>
                    <li><a href="gallery.php">Gallery</a></li>
                    <li><a href="room1.php">Room &amp; Facilities</a></li>
                    <li><a href="reservation.php">Check-Availability</a></li>                    
                   <!-- <li><a href="#review">Review</a></li>-->
                    <li><a href="user.php">Login</a></li>
                    <li><a href="admin.php">Admin</a></li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="http://www.facebook.com/hotel"><img src="images/facebook.png" height="22px" width="22px"></a></li>
		    <li><a href="http://www.instagram.com"><img src="images/ig.png" height="22px" width="22px"></a></li>  
                    <li><a href="http://www.twitter.com"><img src="images/tw.png" height="22px" width="22px"></a></li> 
		   <li><a href="http://www.youtube.com"><img src="images/yt.png" height="25px" width="25px"></a></li>  
                                        
                </ul>
            </div>
        </nav>

     
        <div class="jumbotron">
        <div class="w3-content w3-section">
            <img class="mySlides w3-animate-fading" src="images/home_gallary/1.jpg" style="width:100%; height:450px;">
            <img class="mySlides w3-animate-fading" src="images/home_gallary/2.jpg" style="width:100%; height:450px;">
            <img class="mySlides w3-animate-fading" src="images/home_gallary/3.jpg" style="width:100%; height:450px;">
            <img class="mySlides w3-animate-fading" src="images/home_gallary/4.jpg" style="width:100%; height:450px;">
            <img class="mySlides w3-animate-fading" src="images/home_gallary/5.jpg" style="width:100%; height:450px;">
            <img class="mySlides w3-animate-fading" src="images/home_gallary/6.jpg" style="width:100%; height:450px;">
        </div>    
        </div>
        <hr>
        <a name = "about"><img src = "">
        <div class="row" style="color: #000" >
            <div class="col-md-12 well" >
            <center><h3>HOTEL MAHARAJA</h3><br>    
            
               <h4>At MAHARAJA, nothing gives us more pleasure than making you happy & keeping you delighted!</h4></center><br>
                <p>Rooms categorised into Deluxe Rooms City View, Deluxe Rooms Pool View, and Friends & Family Rooms, are splendidly furnished and facilitated with contemporary amenities. We have a fine-dining restaurant serving multi-cuisine delights, and a speciality restaurant serving oriental delicacies. High Point, the in-house bar, is one of the best bars in Solapur. The hotel has a beautiful garden, a plunge pool, and a well designed poolside with sunbeds. The banquet halls at our hotel can accommodate up to 800 guests and are ideal for weddings and other grand occasions. We have four well-equipped conference halls as well. Guests can unwind at our spa with rejuvenating massages and various other spa treatments. Our travel desk would help you plan your tours around the city. </p>
              <p>Online hotel reservations are a popular method for booking hotel rooms. Travelers can book rooms on a computer by using online security to protect their privacy and financial information and by using several online travel agents to compare prices and facilities at different hotels</p>
              
              <p>Prior to the Internet, travelers could write, telephone the hotel directly, or use a travel agent to make a reservation. Nowadays, online travel agents have pictures of hotels and rooms, information on prices and deals, and even information on local resorts. Many also allow reviews of the traveler to be recorded with the online travel agent.</p>
              
              <p>Online hotel reservations are also helpful for making last minute travel arrangements. Hotels may drop the price of a room if some rooms are still available. There are several websites that specialize in searches for deals on rooms.</p>
              
            </div>  
        </div>
    </a>
        
        <div class="row" style="color:#cfffcf">
            <div class="col-md-4 wellfix">
              <h5>Contact Us</h5><hr>
              Name: Nikhil Khamitkar<br>
              Mail : nikhilkhamitkar1@gmail.com <br>
            </div>
            <div class="col-md-4"></div>
            <div class="col-md-4 wellfix">
                <h5>Developed By</h5><hr>
                <a href="hnccsolapur.org">hnccsolapur.org</a>

            </div>
        </div>
        



    </div>
    
    
    
   

    <script src="my_js/slide.js"></script>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
</body>

</html>