<?php session_start(); include_once '../class.user.php'; $user=new User(); ?>

<!DOCTYPE html>
<html lang="en">

<head>
<style>
 
 form{
    color:#00458B;
    width:100%;
 }
 .main{
     margin:60px 550px ;
     border:2px solid #5EBEC4;
     padding:20px 50px;
     border-radius:5px;
     font-size:20px;
     background:#fff
 }

 label{
   font-size:17px;
   color: black
    }

 input{
    margin:10px auto;
    width:100%;
    border-radius:3px;
    height:25px;
    border:1px solid black;
    
 }
 .f{
   border:none;
 }
 .sub{
    margin:8px auto;
    border:1px solid blue;
    width:30%;
    height:30px;
    border-radius:40px;
    font-size:90%
 }
 .sub:hover{
 background:#7DA2A9; 
}
 h2{
     font-family:Malgun Gothic;
     margin:3px auto 5px auto;
     text-align:center;
 }
 body{
   background:#7981aa
   
 }

</style>
    </script>
</head>

<body>
    <div class="main">
        
            <h2>Log In</h2>
            
            <hr>
            <form action="" method="post" name="login">
                <div class="form-group">
                    <label for="emailusername">Email:</label>
                    <input type="text" name="emailusername" class="form-control" value="
" placeholder = "email" required>
                </div>
                <div class="form-group">
                    <label for="password">Password:</label>
                    <input type="password" name="password" class="form-control" value="" placeholder = "password" required>
                </div>
                <!--For showing error for wrong input  -->
                <center>
                <p id="wrong_id" style=" color:red; font-size:14px; "></p>


                <button type="submit" name="submit" value="Login" onclick="retrun(submitlogin());" class="sub">Submit</button>
                
                <br>
                <p><a href="../reg.php" style="font-size:16px; ">New here? Create Account</a></p>
                
                </center>

                <?php if(isset($_REQUEST[ 'submit'])) { extract($_REQUEST); $login=$user->check_ulogin($emailusername, $password); 
                    if($login) { echo "<script>location='../user.php'</script>"; } 
                else{?>

                <script type="text/javascript">
                    document.getElementById("wrong_id").innerHTML = "Wrong username or password";
                </script>

                <?php } }?>

            </form>
        
    </div>

</body>

</html>