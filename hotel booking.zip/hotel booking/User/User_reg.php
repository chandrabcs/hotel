<?php session_start();
 include_once '../class.user.php';
 $user=new User(); ?>

<!DOCTYPE html>
<html lang = "en">

<head>
    <title>User</title>    
</head>

<body>
    <div class="container">
        <div class="jumbotron">
            <h2>Register</h2>
            
            <hr>
            <form action="" method="post" name="login">
<div class="form-group">
                    <label for="fname">First name:</label>
                    <input type="text" name="fname" class="form-control" value="" placeholder = "First Name" required>
		    <label for="lname">Last name:</label>
                    <input type="text" name="lname" class="form-control" value="" placeholder = "Last Name" required>
                </div>
                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="email" name="email" class="form-control" value="" placeholder = "email" required>
                </div>
 <div class="form-group">
                    <label for="num">Mobile no:</label>
                    <input type="text" name="num" class="form-control" value="" placeholder = "number" required onClick = nvalid()>
                </div>
<div class="form-group">
                    <label for="id">ID Proof:</label>
                    <input type="file" name="id" class="form-control" value="" placeholder = "aadhar/pan" required>
                </div>
                <div class="form-group">
                    <label for="p1">Password:</label>
                    <input type="p1" name="password" class="form-control" value="" placeholder = "create password" required>
                </div>

 <div class="form-group">
                    <label for="p2">Password:</label>
                    <input type="p2" name="password" class="form-control" value="" placeholder = "re-enter password" required>
                </div>
                <!--For showing error for wrong input  -->
                <p id="wrong_id" style=" color:red; font-size:12px;"></p>


                <button type="submit" name="submit" value="Login" onclick="submitlogin()" class="btn btn-lg btn-primary btn-block">Submit</button>
                
                <br>
                <p style="text-align: center; font-size: 14px;"><a href="../index.php">Back To Home</a></p>


            </form>
        </div>
    </div>

<script language="javascript" type="text/javascript">
function submitlogin() {
            var form = document.login;
            if(form.num.value.length != 10)
            if (form.p1.value == "" || form.p2.value == "") {
                alert("Please Enter Password");
                return false;
            } 
	if (form.p2.value != form.p1.value ) {
                alert("Password does not match");
                return false;
            }
	alert("You are registred Successfully")	
        }
    </script>
</body>

</html>