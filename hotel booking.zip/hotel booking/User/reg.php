<?php session_start(); include_once '../admin/include/class.user.php'; $user=new User(); ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>User</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href = "../admin/css/login.css" type = "text/css" rel = "stylesheet">
    <link rel="stylesheet" href="css/login.css" type="text/css">

    <script language="javascript" type="text/javascript">
        function submitlogin() {
            getElementsByName()
            var form = document.getElementsByName('login');
            if (form.elements['email'].value == "") {
                alert("Enter email or username.");
                
            } else if (form.elements['password'].value == "") {
                alert("Enter Password.");
                
            }
	alert("You are registred Successfully");
        }
    </script>
</head>

<body>
    <div class="container">
        <div class="jumbotron">
            <h2>Register</h2>
            
            <hr>
            <form action="#" method="post" name="login">
<div class="form-group">
                    <label for="fname">First name:</label>
                    <input type="text" name="fname" class="form-control" value="
" placeholder = "First Name" required>
		    <label for="fname">Last name:</label>
                    <input type="text" name="lname" class="form-control" value="
" placeholder = "Last Name" required>
                </div>
                <div class="form-group">
                    <label for="emailusername">Email:</label>
                    <input type="text" name="emailusername" class="form-control" value="
" placeholder = "email" required>
                </div>
 <div class="form-group">
                    <label for="password">Mobile no:</label>
                    <input type="number" name="password" class="form-control" value="" placeholder = "number" required>
                </div>
<div class="form-group">
                    <label for="emailusername">ID Proof:</label>
                    <input type="file" name="emailusername" class="form-control" value="
" placeholder = "aadhar/pan" required>
                </div>
                <div class="form-group">
                    <label for="password">Password:</label>
                    <input type="password" name="password" class="form-control" value="" placeholder = "create password" required>
                </div>

 <div class="form-group">
                    <label for="password">Password:</label>
                    <input type="password" name="password" class="form-control" value="" placeholder = "re-enter password" required>
                </div>      


                <button type="submit" name="submit" value="Login" onclick="submitlogin();" class="btn btn-lg btn-primary btn-block">Submit</button>
                
                <br>
                
            </form>
        </div>
    </div>

</body>

</html>